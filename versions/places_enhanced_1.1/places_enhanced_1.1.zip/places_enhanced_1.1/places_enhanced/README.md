### GeoGuessr Chrome Extension ###
- Location overlay with cleaner look
- learnable meta for every state featured on geoguessr

### KEYBINDS WITH SAFE-MODE OFF ###
- press `Ctrl + Shift` to display a custom popup with the location information.
- 'SAFE-MODE' Checkbox in settings menu

Currently full meta added for:

