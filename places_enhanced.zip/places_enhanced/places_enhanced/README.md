# GeoGuessr Chrome Extension
- Location overlay

KEYBINDS WITH SAFE-MODE OFF
   - press `Ctrl + Shift` to display a custom popup with the location information.
   - 'SAFE-MODE' Checkbox in settings menu

