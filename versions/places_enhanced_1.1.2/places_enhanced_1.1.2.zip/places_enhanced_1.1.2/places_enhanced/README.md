### GeoGuessr Chrome Extension ###
- Location overlay with cleaner look
- learnable meta for every state featured on geoguessr


### changelog ###
- added a way that web requests give consistently the Right state info even when using aliases
- added a way that the overlay actually features only the available meta without displaying empty Slots
- changed logo from default tampermonkey to a copyright free svg graphic
- made the overlay scrollable to get a closer look at all the meta-details when zooming
- fixed hud and icon color to be more pleasing


### KEYBINDS with safe-mode off ###
- press `Ctrl + Shift` to display a custom popup with the location information.
- 'SAFE-MODE' Checkbox in settings menu


Currently full meta added for:
- Malaysia
