### GeoGuessr Chrome Extension ###
- Location overlay with cleaner look
- learnable meta for every state featured on geoguessr
- added a way that web requests give consistently the Right state info even when using aliases
- added a way that the overlay actually features only the available meta without displaying empty Slots
- changed logo from default tampermonkey to a copyright free svg graphic

### KEYBINDS WITH SAFE-MODE OFF ###
- press `Ctrl + Shift` to display a custom popup with the location information.
- 'SAFE-MODE' Checkbox in settings menu

Currently full meta added for:
- Malaysia
